"""
Utility functions package
"""
